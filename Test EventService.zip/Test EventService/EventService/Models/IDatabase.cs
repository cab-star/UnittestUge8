﻿namespace EventService.Models
{
    public interface IDatabase
    {
        public void Add(Event e);
        public int Count();
        public List<Event> GetRange(int startIndex,int antal);

    }
}
