﻿namespace EventService.Models
{
    public class Events : IDatabase
    {
       private static List<Event>? _events;

        public void Add(Event e)
        {
            _events?.Add(e);
        }

        public int Count()
        {
            int i = _events.Count;            
            return i;
        }

        public List<Event> GetRange(int startIndex, int antal)
        {           
            return _events.GetRange(startIndex, antal);
       
        }
    }
}
