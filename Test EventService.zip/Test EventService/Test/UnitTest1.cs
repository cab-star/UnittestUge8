
using EventService;
using Xunit;
using Moq;
using EventService.Controllers;
using Microsoft.AspNetCore.Mvc;
using EventService.Models;

namespace Test
{

    public class UnitTest1
    {

        [Fact]
        public void EventControllerTest()
        {
           var _mock_EventDB = new Mock<IDatabase>();
           var e = new Event();

            e.EventNo = 1;
            e.TableNo = 1;
            e.PizzaNo = 26;
            _mock_EventDB.Setup(x => x.Add(e));

            var _controller = new EventController(_mock_EventDB.Object);
            List<Event> subList = new();
            subList = _controller.ListEvents(0,1);
            var res = subList.First();

            Assert.Equal(1, res.EventNo);
        }

    }
}